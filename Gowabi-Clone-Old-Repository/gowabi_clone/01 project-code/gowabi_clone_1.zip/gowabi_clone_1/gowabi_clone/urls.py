from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('booking/', include('booking.urls')),
    path('user/', include('user.urls')),
    path('vendor/', include('vendor.urls')),
    path('payment/', include('payment.urls')),
]
